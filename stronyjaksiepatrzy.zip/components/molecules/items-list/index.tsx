import React from 'react'

const ItemsList = () => {
  return (
    <div className="mb-10 border rounded-lg">
  </div>
  )
}

export default ItemsList;
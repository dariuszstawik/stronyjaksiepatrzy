export const navbarData = [

{
    id: 1,
    title: "O mnie",
    path: "#aboutSection",
},

{
    id: 2,
    title: "Oferta",
    path: "#offerSection",
},

{
    id: 3,
    title: "Dlaczego ja",
    path: "#featuresSection",
},

{
    id: 4,
    title: "Realizacje",
    path: "#projectFeatured",
},

{
    id: 5,
    title: "Ceny",
    path: "#pricingSection",
}

]
(() => {
var exports = {};
exports.id = 931;
exports.ids = [931];
exports.modules = {

/***/ 6270:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 7999:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 1090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 8652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 7244:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 9274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 1017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 7310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppRouter: () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   LayoutRouter: () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   RenderFromTemplateContext: () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   StaticGenerationSearchParamsBailoutProvider: () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   __next_app_webpack_require__: () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   actionAsyncStorage: () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   createSearchParamsBailoutProxy: () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   decodeAction: () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   decodeReply: () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   preconnect: () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   preloadFont: () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   preloadStyle: () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   renderToReadableStream: () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   requestAsyncStorage: () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   serverHooks: () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   staticGenerationAsyncStorage: () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   staticGenerationBailout: () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4592);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6301);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7431);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(94);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4437);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6127);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5486);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6404);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2527);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3332);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7902);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3099);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 1379)), "C:\\Users\\dariu\\Documents\\programowanie\\stronyjaksiepatrzy\\app\\page.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 729)), "C:\\Users\\dariu\\Documents\\programowanie\\stronyjaksiepatrzy\\app\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["C:\\Users\\dariu\\Documents\\programowanie\\stronyjaksiepatrzy\\app\\page.tsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/page"
  

/***/ }),

/***/ 404:
/***/ (() => {



/***/ }),

/***/ 8748:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 125, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 6249, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 7844, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 1522, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3100, 23))

/***/ }),

/***/ 7566:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3481, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5246));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 7977, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7678));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 7649, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2083));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3091))

/***/ }),

/***/ 2083:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1621);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* __next_internal_client_entry_do_not_use__ default auto */ 


const Button = ({ children, version, path, isExternalLink, isTargetBlank, ...rest })=>{
    const handleScroll = (e)=>{
        e.preventDefault();
        const href = e.currentTarget.href;
        const targetId = href.replace(/.*\#/, "");
        const elem = document.getElementById(targetId);
        elem?.scrollIntoView({
            behavior: "smooth"
        });
    };
    const onClickHandler = isExternalLink ? undefined : handleScroll;
    if (isExternalLink) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
            onClick: onClickHandler,
            className: (()=>{
                switch(version){
                    case "white":
                        return "block w-full md:w-auto text-center py-4 px-8 text-sm font-medium leading-normal rounded border hover:border-gray-300";
                    case "inContact":
                        return "inline-block py-3 px-8 text-sm leading-normal font-medium bg-red-50 hover:bg-red-100 text-red-500 rounded transition duration-200";
                    default:
                        return "block w-full md:w-auto text-center py-4 px-8 md:mr-4 text-sm text-white font-medium leading-normal bg-red-400 hover:bg-blue-400 rounded transition duration-200";
                }
            })(),
            target: isTargetBlank ? "_blank" : "",
            href: path,
            children: children
        });
    } else {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
            onClick: onClickHandler,
            className: (()=>{
                switch(version){
                    case "white":
                        return "block w-full md:w-auto text-center py-4 px-8 text-sm font-medium bg-white leading-normal rounded border hover:border-gray-300";
                    case "inContact":
                        return "inline-block py-3 px-8 text-sm leading-normal font-medium bg-red-50 hover:bg-red-100 text-red-500 rounded transition duration-200";
                    default:
                        return "block w-full md:w-auto text-center py-4 px-8 md:mr-4 text-sm text-white font-medium leading-normal bg-red-400 hover:bg-blue-400 rounded transition duration-200";
                }
            })(),
            href: path,
            children: children
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Button);


/***/ }),

/***/ 7678:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* __next_internal_client_entry_do_not_use__ default auto */ 

const Logo = ({ closeMobileMenu })=>{
    const handleScroll = (e)=>{
        e.preventDefault();
        const href = e.currentTarget.href;
        const targetId = href.replace(/.*\#/, "");
        const elem = document.getElementById(targetId);
        elem?.scrollIntoView({
            behavior: "smooth"
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
        className: "ml-4 text-sm lg:text-xl font-semibold",
        href: "#top",
        onClick: (e)=>{
            {
                closeMobileMenu ? closeMobileMenu() : "";
            }
            handleScroll(e);
        },
        children: [
            "Strony ",
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "leading-tight text-red-400",
                children: "jak się patrzy"
            }),
            " "
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Logo);


/***/ }),

/***/ 3091:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ navbar)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
;// CONCATENATED MODULE: ./components/atoms/hamburger/index.tsx


const Hamburger = ({ hasCloseIcon, toggleMobileMenu })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: hasCloseIcon ? /*#__PURE__*/ jsx_runtime_.jsx("svg", {
            onClick: toggleMobileMenu,
            className: "block w-8 my-4 lg:hidden",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "1.5",
            viewBox: "0 0 24 24",
            xmlns: "http://www.w3.org/2000/svg",
            "aria-hidden": "true",
            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                d: "M6 18L18 6M6 6l12 12"
            })
        }) : /*#__PURE__*/ jsx_runtime_.jsx("svg", {
            onClick: toggleMobileMenu,
            className: "block w-8 my-4 lg:hidden",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "1.5",
            viewBox: "0 0 24 24",
            xmlns: "http://www.w3.org/2000/svg",
            "aria-hidden": "true",
            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                d: "M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5"
            })
        })
    });
};
/* harmony default export */ const hamburger = (Hamburger);

// EXTERNAL MODULE: ./components/atoms/logo/index.tsx
var logo = __webpack_require__(7678);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/molecules/navbar/navbarData.tsx
const navbarData = [
    {
        id: 1,
        title: "O mnie",
        path: "#aboutSection"
    },
    {
        id: 2,
        title: "Oferta",
        path: "#offerSection"
    },
    {
        id: 3,
        title: "Dlaczego ja",
        path: "#featuresSection"
    },
    {
        id: 4,
        title: "Realizacje",
        path: "#projectFeatured"
    },
    {
        id: 5,
        title: "Ceny",
        path: "#pricingSection"
    }
];

;// CONCATENATED MODULE: ./components/molecules/navlinks/index.tsx




const Navlinks = ({ isVisible, closeMobileMenu })=>{
    const handleScroll = (e)=>{
        e.preventDefault();
        const href = e.currentTarget.href;
        const targetId = href.replace(/.*\#/, "");
        const elem = document.getElementById(targetId);
        elem?.scrollIntoView({
            behavior: "smooth"
        });
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("ul", {
        className: isVisible ? "bg-white text-sm font-medium list-none absolute z-40 w-full top-full left-0 bg-backgroundGray py-4 flex flex-col justify-center align-center items-center gap-10 lg:static lg:flex-row my-4 ml-4" : "bg-white text-sm font-medium list-none flex-col justify-center align-center items-center gap-10 lg:flex-row my-4 hidden lg:flex ml-4",
        children: navbarData.map((navlink, i)=>{
            return /*#__PURE__*/ jsx_runtime_.jsx("li", {
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: navlink.path,
                    onClick: (e)=>{
                        closeMobileMenu();
                        handleScroll(e);
                    },
                    children: navlink.title
                })
            }, i);
        })
    });
};
/* harmony default export */ const navlinks = (Navlinks);

// EXTERNAL MODULE: ./components/atoms/button/index.tsx
var atoms_button = __webpack_require__(2083);
;// CONCATENATED MODULE: ./components/molecules/navbar/index.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 





const Navbar = ()=>{
    const [isMobileMenuActive, setIsMobileMenuActive] = (0,react_.useState)(false);
    const toggleMobileMenu = ()=>{
        setIsMobileMenuActive(!isMobileMenuActive);
    };
    const closeMobileMenu = ()=>{
        setIsMobileMenuActive(false);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "fixed w-full h-28 flex justify-between items-center px-4 lg:px-16 py-4 bg-white top-0 left-0 z-30",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(logo["default"], {
                closeMobileMenu: closeMobileMenu
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "pl-16 w-3/5 flex justify-end lg:justify-between content-center items-center gap-6",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(navlinks, {
                        isVisible: isMobileMenuActive,
                        closeMobileMenu: closeMobileMenu
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(atoms_button["default"], {
                        version: "white",
                        path: "#contactSection",
                        children: "Kontakt"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(hamburger, {
                        hasCloseIcon: isMobileMenuActive ? true : false,
                        toggleMobileMenu: toggleMobileMenu
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const navbar = (Navbar);


/***/ }),

/***/ 5246:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ contact_section)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
;// CONCATENATED MODULE: ./components/atoms/email-icon/index.tsx


const EmailIcon = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        className: "w-8 inline-block mr-4",
        fill: "none",
        stroke: "currentColor",
        strokeWidth: "1.5",
        viewBox: "0 0 24 24",
        xmlns: "http://www.w3.org/2000/svg",
        "aria-hidden": "true",
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            strokeLinecap: "round",
            strokeLinejoin: "round",
            d: "M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75"
        })
    });
};
/* harmony default export */ const email_icon = (EmailIcon);

// EXTERNAL MODULE: ./node_modules/@emailjs/browser/cjs/index.js
var cjs = __webpack_require__(5366);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(8421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/organisms/contact-section/index.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 




const ContactSection = ()=>{
    const form = (0,react_.useRef)(null);
    const [showNotification, setShowNotification] = (0,react_.useState)(false);
    (0,react_.useEffect)(()=>{
        if (showNotification) {
            const timer = setTimeout(()=>{
                setShowNotification(false);
            }, 3000);
            return ()=>clearTimeout(timer);
        }
    }, [
        showNotification
    ]);
    const sendEmail = (e)=>{
        e.preventDefault();
        cjs/* default.sendForm */.ZP.sendForm( true ? "service_tqx7x51" : 0,  true ? "template_7ihan6i" : 0, form.current ? form.current : "",  true ? "3tW6XehV7t660HUl9" : 0);
        setShowNotification(true);
        e.target && e.target.reset();
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "py-32",
        id: "contactSection",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container px-4 mx-auto relative",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-wrap -mx-4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full lg:w-1/2 px-4 mb-12 lg:mb-0",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "max-w-md",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                    className: "mb-12 text-4xl font-semibold font-heading",
                                    children: [
                                        "Skontaktuj się",
                                        /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                        " ze mną"
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "my-2",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            className: "mb-4 text-2xl font-semibold",
                                            children: "E-mail"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "text-gray-500",
                                            children: "Jeżeli od formularz wolisz tradycyjny mail, napisz:"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "my-6 flex items-center",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(email_icon, {}),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "text-gray-500",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "mailto: dariusz.stawik@gmail.com",
                                                        children: "dariusz.stawik@gmail.com"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "my-8",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            className: "mb-4 text-2xl font-semibold",
                                            children: "Linkedin i Github"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "text-gray-500",
                                            children: "Sprawdź moje profile w serwisach:"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "my-6 flex items-center",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    href: "https://linkedin.com/in/dariusz-stawik",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        src: "/linkedin.svg",
                                                        className: "mr-4",
                                                        alt: "ikona Linkedin",
                                                        width: 32,
                                                        height: 32
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    href: "https://github.com/dariuszstawik",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        src: "/github.svg",
                                                        className: "mr-4",
                                                        alt: "ikona Github",
                                                        width: 32,
                                                        height: 32
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {})
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "w-full lg:w-1/2 px-4",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                                ref: form,
                                onSubmit: sendEmail,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "relative flex flex-wrap mb-6",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                className: "relative mb-2 md:mb-0 w-full py-4 pl-4 text-sm border rounded",
                                                type: "text",
                                                name: "user_name"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "absolute top-0 left-0 ml-4 -mt-2 px-1 inline-block bg-white text-gray-500 text-xs",
                                                children: "Imię i nazwisko"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "relative flex flex-wrap mb-6",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                className: "relative mb-2 md:mb-0 w-full py-4 pl-4 text-sm border rounded",
                                                type: "email",
                                                name: "user_email"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "absolute top-0 left-0 ml-4 -mt-2 px-1 inline-block bg-white text-gray-500 text-xs",
                                                children: "Adres e-mail"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "relative flex flex-wrap mb-6",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                                                className: "relative mb-2 md:mb-0 w-full py-4 pl-4 text-sm border rounded resize-none",
                                                id: "1",
                                                name: "message",
                                                cols: 30,
                                                rows: 10,
                                                defaultValue: ""
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "absolute top-0 left-0 ml-4 -mt-2 px-1 inline-block bg-white text-gray-500 text-xs",
                                                children: "Wiadomość"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        type: "submit",
                                        className: "w-full inline-block px-6 py-4 text-sm text-white bg-red-400 hover:bg-blue-400 rounded transition duration-200",
                                        children: "Wyślij"
                                    })
                                ]
                            }),
                            showNotification && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "text-green-500 py-2 px-4 absolute top-100 right-0 mt-2 mr-2 rounded",
                                children: "Wiadomość wysłana. Dziękujemy!"
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const contact_section = (ContactSection);


/***/ }),

/***/ 729:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ RootLayout),
/* harmony export */   metadata: () => (/* binding */ metadata)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_font_google_target_css_path_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(160);
/* harmony import */ var next_font_google_target_css_path_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_font_google_target_css_path_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2817);
/* harmony import */ var _globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_globals_css__WEBPACK_IMPORTED_MODULE_1__);



const metadata = {
    title: "Strony jak się patrzy",
    description: "Strony jak się patrzy w cenach jakich mało"
};
function RootLayout({ children }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("html", {
        lang: "pl",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("body", {
            className: (next_font_google_target_css_path_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_2___default().className),
            children: children
        })
    });
}


/***/ }),

/***/ 1379:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(1313);
;// CONCATENATED MODULE: ./components/atoms/button/index.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\dariu\Documents\programowanie\stronyjaksiepatrzy\components\atoms\button\index.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const atoms_button = (__default__);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(7887);
;// CONCATENATED MODULE: ./components/atoms/icon-asset/index.tsx


const IconAsset = ({ version })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("img", {
        className: "hidden xl:block absolute right-0 bottom-0 mb-64",
        src: version === "v2" ? "blue-dot-left-bars.svg" : "yellow-dot-right-shield.svg",
        alt: "asset icon"
    });
};
/* harmony default export */ const icon_asset = (IconAsset);

;// CONCATENATED MODULE: ./components/atoms/section-paragraph/index.tsx


const SectionParagraph = ({ children })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("p", {
        className: "my-2 text-gray-500 text-lg",
        children: children
    });
};
/* harmony default export */ const section_paragraph = (SectionParagraph);

;// CONCATENATED MODULE: ./components/atoms/section-supertitle/index.tsx


const SectionSupertitle = ({ children })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("span", {
        className: "text-xs text-blue-400 font-semibold",
        children: children
    });
};
/* harmony default export */ const section_supertitle = (SectionSupertitle);

;// CONCATENATED MODULE: ./components/atoms/section-title/index.tsx


const SectionTitle = ({ children })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("h2", {
        className: "mt-4 mb-6 text-4xl font-semibold",
        children: children
    });
};
/* harmony default export */ const section_title = (SectionTitle);

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(993);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/organisms/about-section/index.tsx








const AboutSection = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "relative py-16",
        id: "aboutSection",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "relative container px-4 mx-auto",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex flex-wrap items-center -mx-4",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "w-full lg:w-1/2 px-4 mb-12 lg:mb-0",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "max-w-lg",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(section_supertitle, {
                                        children: "strony jak się patrzy"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(section_title, {
                                        children: "Cześć,"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(section_paragraph, {
                                        children: [
                                            " ",
                                            "Nazywam się Dariusz Stawik i chętnie stworzę dla Ciebie nowoczesną i funkcjonalną stronę internetową. Jestem programistą frontend, webmasterem i specjalistą ds. marketingu. Jako programista zbieram pierwsze doświadczenia, w marketingu (gł\xf3wnie w organizacjach pozarządowych) spędziłem ponad 10 lat. Ponieważ buduję portfolio programistyczne, na początek oferuję strony i aplikacje w okazyjnych cenach. Czy efekty będą r\xf3wnie atrakcyjne? Przekonaj się - sprawdź moje realizacje.",
                                            " "
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "mt-8",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(atoms_button, {
                                            path: "#projectFeatured",
                                            children: "Przejdź do realizacji"
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "relative w-full lg:w-1/2 px-4",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: "rounded-xl object-cover lg:h-128",
                                src: "/DS4.jpg",
                                alt: "Dariusz Stawik",
                                width: 900,
                                height: 998
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(icon_asset, {})
        ]
    });
};
/* harmony default export */ const about_section = (AboutSection);

;// CONCATENATED MODULE: ./components/organisms/contact-section/index.tsx

const contact_section_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\dariu\Documents\programowanie\stronyjaksiepatrzy\components\organisms\contact-section\index.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: contact_section_esModule, $$typeof: contact_section_$$typeof } = contact_section_proxy;
const contact_section_default_ = contact_section_proxy.default;


/* harmony default export */ const contact_section = (contact_section_default_);
;// CONCATENATED MODULE: ./components/molecules/section-header/index.tsx




const SectionHeader = ({ superTitle, title, isCentered })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: isCentered ? "flex flex-col justify-center" : "",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(section_supertitle, {
                children: superTitle
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(section_title, {
                children: title
            })
        ]
    });
};
/* harmony default export */ const section_header = (SectionHeader);

;// CONCATENATED MODULE: ./components/organisms/features-section/index.tsx



const FeaturesSection = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "relative py-20",
        id: "featuresSection",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container px-4 mx-auto",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "max-w-2xl mb-28 mx-auto text-center",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(section_header, {
                            superTitle: "strony jak się patrzy",
                            title: "Dlaczego ja?",
                            isCentered: true
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "max-w-lg mx-auto text-xl text-gray-500",
                            children: "Firm i os\xf3b projektujących strony internetowe jest wiele. Zobacz, co wyr\xf3żnia moją ofertę"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex flex-wrap -mx-3 -mb-10 lg:-mb-16",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "w-full md:w-1/2 lg:w-1/3 px-3 mb-10 lg:mb-16",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "relative pt-16 pb-12 px-8 bg-gray-50 rounded-lg text-center hover:bg-white hover:shadow-2xl",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "absolute top-0 inset-x-0 -mt-6 flex justify-center items-center w-16 h-16 mx-auto rounded-full bg-blue-400 text-white",
                                        children: "1"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: "mb-6 text-2xl font-semibold font-heading",
                                        children: "korzystne ceny"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-gray-500",
                                        children: "Buduję swoje portfolio, więc na początek oferuję strony w atrakcyjnych cenach."
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "w-full md:w-1/2 lg:w-1/3 px-3 mb-10 lg:mb-16",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "relative pt-16 pb-12 px-8 bg-gray-50 rounded-lg text-center hover:bg-white hover:shadow-2xl",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "absolute top-0 inset-x-0 -mt-6 flex justify-center items-center w-16 h-16 mx-auto rounded-full bg-teal-500 text-white",
                                        children: "2"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: "mb-6 text-2xl font-semibold font-heading",
                                        children: "wydajność i bezpieczeństwo"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-gray-500",
                                        children: "Tworzę strony w oparciu o technologie Next.js i Contentful CMS - działają szybciej i są bezpieczniejsze od stron zbudowanych na Wordpressie."
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "w-full md:w-1/2 lg:w-1/3 px-3 mb-10 lg:mb-16",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "relative pt-16 pb-12 px-8 bg-gray-50 rounded-lg text-center hover:bg-white hover:shadow-2xl",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "absolute top-0 inset-x-0 -mt-6 flex justify-center items-center w-16 h-16 mx-auto rounded-full bg-red-500 text-white",
                                        children: "3"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: "mb-6 text-2xl font-semibold font-heading",
                                        children: "poprawki bez limitu"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-gray-500",
                                        children: "Zależy mi, żeby każdy klient był w pełni zadowolony z efekt\xf3w wsp\xf3łpracy."
                                    })
                                ]
                            })
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const features_section = (FeaturesSection);

;// CONCATENATED MODULE: ./components/atoms/logo/index.tsx

const logo_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\dariu\Documents\programowanie\stronyjaksiepatrzy\components\atoms\logo\index.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: logo_esModule, $$typeof: logo_$$typeof } = logo_proxy;
const logo_default_ = logo_proxy.default;


/* harmony default export */ const logo = (logo_default_);
;// CONCATENATED MODULE: ./components/molecules/navbar/navbarData.tsx
const navbarData = [
    {
        id: 1,
        title: "O mnie",
        path: "#aboutSection"
    },
    {
        id: 2,
        title: "Oferta",
        path: "#offerSection"
    },
    {
        id: 3,
        title: "Dlaczego ja",
        path: "#featuresSection"
    },
    {
        id: 4,
        title: "Realizacje",
        path: "#projectFeatured"
    },
    {
        id: 5,
        title: "Ceny",
        path: "#pricingSection"
    }
];

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(4834);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/organisms/footer/index.tsx





const Footer = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "py-20 bg-gray-50",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container mx-auto px-4",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-wrap justify-between items-center -mx-4",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "w-full lg:w-2/6 px-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "inline-block mb-6",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(logo, {})
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "hidden lg:block text-sm text-gray-500",
                                children: "All rights reserved \xa9 Dariusz Stawik 2023"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "w-full lg:w-4/6 px-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "flex flex-wrap items-center justify-end",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                    className: "w-full lg:w-auto inline-flex flex-wrap mb-4 lg:mb-0 md:mr-6 lg:mr-12",
                                    children: navbarData.map((item, i)=>{
                                        return /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "mr-12 mb-2 md:mb-0",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                className: "text-sm font-medium",
                                                href: item.path,
                                                children: item.title
                                            })
                                        }, i);
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "mt-6 lg:hidden text-sm text-gray-500",
                                children: "All rights reserved \xa9 Dariusz Stawik 2023"
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const footer = (Footer);

;// CONCATENATED MODULE: ./components/atoms/header-img/index.tsx



const HeaderImg = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
        className: "block w-full h-full object-cover z-30 lg:w-2/5 lg:absolute lg:top-0 lg:left-0",
        src: "/yak.jpg",
        alt: "zdjęcie jaka pracującego na laptopie",
        width: 1015,
        height: 1015,
        priority: true
    });
};
/* harmony default export */ const header_img = (HeaderImg);

;// CONCATENATED MODULE: ./components/molecules/header-content/index.tsx



const HeaderContent = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "relative container px-4 mx-auto pb-20 mt-24",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "w-full lg:w-3/5 lg:pl-16 ml-auto",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "mt-10 lg:mt-20 max-w-2xl lg:pr-10",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "max-w-xl",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                className: "mb-6 lg:mb-12 text-4xl lg:text-5xl font-semibold",
                                children: [
                                    "Strony",
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "leading-tight block text-red-400",
                                        children: "jak się patrzy"
                                    }),
                                    " ",
                                    "w cenach, jakich mało"
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "max-w-md mb-6 lg:mb-14 text-gray-500 leading-relaxed",
                                children: "Potrzebujesz strony internetowej lub prostej aplikacji? Koniecznie zapoznaj się z moją ofertą!"
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex flex-wrap mb-16 lg:mb-20",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(atoms_button, {
                            path: "#offerSection",
                            children: "Sprawdź ofertę"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(atoms_button, {
                            version: "white",
                            path: "#contactSection",
                            children: "Wyślij wiadomość"
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const header_content = (HeaderContent);

;// CONCATENATED MODULE: ./components/molecules/navbar/index.tsx

const navbar_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\dariu\Documents\programowanie\stronyjaksiepatrzy\components\molecules\navbar\index.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: navbar_esModule, $$typeof: navbar_$$typeof } = navbar_proxy;
const navbar_default_ = navbar_proxy.default;


/* harmony default export */ const navbar = (navbar_default_);
;// CONCATENATED MODULE: ./components/organisms/header/index.tsx






const Header = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "relative overflow-y-hidden z-20 bg-white",
        id: "top",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(navbar, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "relative flex flex-col-reverse",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(header_img, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(header_content, {})
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(icon_asset, {})
        ]
    });
};
/* harmony default export */ const header = (Header);

;// CONCATENATED MODULE: ./components/atoms/list-item/index.tsx


const ListItem = ({ children })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex p-4 border-b",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                className: "mr-4 mt-1",
                width: 20,
                height: 20,
                viewBox: "0 0 20 20",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M5.67 0H14.34C17.73 0 20 2.38 20 5.92V14.091C20 17.62 17.73 20 14.34 20H5.67C2.28 20 0 17.62 0 14.091V5.92C0 2.38 2.28 0 5.67 0ZM9.43 12.99L14.18 8.24C14.52 7.9 14.52 7.35 14.18 7C13.84 6.66 13.28 6.66 12.94 7L8.81 11.13L7.06 9.38C6.72 9.04 6.16 9.04 5.82 9.38C5.48 9.72 5.48 10.27 5.82 10.62L8.2 12.99C8.37 13.16 8.59 13.24 8.81 13.24C9.04 13.24 9.26 13.16 9.43 12.99Z",
                    fill: "#45C1FF"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                className: "font-semibold font-heading",
                children: children
            })
        ]
    });
};
/* harmony default export */ const list_item = (ListItem);

;// CONCATENATED MODULE: ./components/organisms/offer-section/index.tsx






const OfferSection = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "relative py-20",
        id: "offerSection",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container px-4 mx-auto",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-wrap items-start -mx-4",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "relative w-full md:w-1/2 px-4 mb-12 md:mb-0",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                className: "hidden lg:block absolute bottom-0 left-0 -mb-10 -ml-28",
                                src: "blue-dot-left-bars.svg",
                                alt: ""
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: "h-96 lg:h-128 w-full rounded-xl object-cover",
                                src: "/jaksiepatrzy-kwadrat1.jpg",
                                alt: "zdjęcia jak\xf3w wyświetlonyvh na r\xf3żnych urządzeniach",
                                width: 1015,
                                height: 1018
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "relative w-full md:w-1/2 px-4 pb-20 lg:pb-0",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "lg:ml-auto max-w-md",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                    className: "mb-6 lg:mb-10 text-4xl font-semibold font-heading"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(section_header, {
                                    superTitle: "strony jak się patrzy",
                                    title: "Oferta"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(section_paragraph, {
                                    children: "Chętnie wykonam dla Ciebie prostą stronę internetową lub aplikację, np.:"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: "my-4",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(list_item, {
                                                children: "stronę firmową,"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(list_item, {
                                                children: "stronę projektu,"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(list_item, {
                                                children: "stronę portfolio."
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(section_paragraph, {
                                    children: "Moje projekty są w pełni responsywne oraz posiadają CMS."
                                })
                            ]
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const offer_section = (OfferSection);

;// CONCATENATED MODULE: ./components/molecules/pricing-card-premium/index.tsx



const PricingcardPremium = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "w-full md:w-1/2 lg:w-1/3 px-3",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "pt-12 pb-8 px-8 bg-white border rounded-xl lg:text-center",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                    className: "mb-6 font-semibold text-gray-500",
                    children: "Premium"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex lg:justify-center mb-8",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "self-start inline-block mr-2 font-semibold text-gray-500",
                            children: "od"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "self-end text-5xl font-semibold font-heading",
                            children: "1890 zł"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                    className: "mb-6 text-left",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            className: "flex items-center py-4 border-b",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    className: "mr-2",
                                    width: 20,
                                    height: 20,
                                    viewBox: "0 0 20 20",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        fillRule: "evenodd",
                                        clipRule: "evenodd",
                                        d: "M5.67 0H14.34C17.73 0 20 2.38 20 5.92V14.091C20 17.62 17.73 20 14.34 20H5.67C2.28 20 0 17.62 0 14.091V5.92C0 2.38 2.28 0 5.67 0ZM9.43 12.99L14.18 8.24C14.52 7.9 14.52 7.35 14.18 7C13.84 6.66 13.28 6.66 12.94 7L8.81 11.13L7.06 9.38C6.72 9.04 6.16 9.04 5.82 9.38C5.48 9.72 5.48 10.27 5.82 10.62L8.2 12.99C8.37 13.16 8.59 13.24 8.81 13.24C9.04 13.24 9.26 13.16 9.43 12.99Z",
                                        fill: "#45C1FF"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "font-medium",
                                    children: "strona gł\xf3wna + do 8 podstron,"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            className: "flex items-center py-4 border-b",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    className: "mr-2",
                                    width: 20,
                                    height: 20,
                                    viewBox: "0 0 20 20",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        fillRule: "evenodd",
                                        clipRule: "evenodd",
                                        d: "M5.67 0H14.34C17.73 0 20 2.38 20 5.92V14.091C20 17.62 17.73 20 14.34 20H5.67C2.28 20 0 17.62 0 14.091V5.92C0 2.38 2.28 0 5.67 0ZM9.43 12.99L14.18 8.24C14.52 7.9 14.52 7.35 14.18 7C13.84 6.66 13.28 6.66 12.94 7L8.81 11.13L7.06 9.38C6.72 9.04 6.16 9.04 5.82 9.38C5.48 9.72 5.48 10.27 5.82 10.62L8.2 12.99C8.37 13.16 8.59 13.24 8.81 13.24C9.04 13.24 9.26 13.16 9.43 12.99Z",
                                        fill: "#45C1FF"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "font-medium",
                                    children: "responsywność,"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            className: "flex items-center py-4 border-b",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    className: "mr-2",
                                    width: 20,
                                    height: 20,
                                    viewBox: "0 0 20 20",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        fillRule: "evenodd",
                                        clipRule: "evenodd",
                                        d: "M5.67 0H14.34C17.73 0 20 2.38 20 5.92V14.091C20 17.62 17.73 20 14.34 20H5.67C2.28 20 0 17.62 0 14.091V5.92C0 2.38 2.28 0 5.67 0ZM9.43 12.99L14.18 8.24C14.52 7.9 14.52 7.35 14.18 7C13.84 6.66 13.28 6.66 12.94 7L8.81 11.13L7.06 9.38C6.72 9.04 6.16 9.04 5.82 9.38C5.48 9.72 5.48 10.27 5.82 10.62L8.2 12.99C8.37 13.16 8.59 13.24 8.81 13.24C9.04 13.24 9.26 13.16 9.43 12.99Z",
                                        fill: "#45C1FF"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "font-medium",
                                    children: "CMS,"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            className: "flex items-center py-4 border-b",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    className: "mr-2",
                                    width: 20,
                                    height: 20,
                                    viewBox: "0 0 20 20",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        fillRule: "evenodd",
                                        clipRule: "evenodd",
                                        d: "M5.67 0H14.34C17.73 0 20 2.38 20 5.92V14.091C20 17.62 17.73 20 14.34 20H5.67C2.28 20 0 17.62 0 14.091V5.92C0 2.38 2.28 0 5.67 0ZM9.43 12.99L14.18 8.24C14.52 7.9 14.52 7.35 14.18 7C13.84 6.66 13.28 6.66 12.94 7L8.81 11.13L7.06 9.38C6.72 9.04 6.16 9.04 5.82 9.38C5.48 9.72 5.48 10.27 5.82 10.62L8.2 12.99C8.37 13.16 8.59 13.24 8.81 13.24C9.04 13.24 9.26 13.16 9.43 12.99Z",
                                        fill: "#45C1FF"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "font-medium",
                                    children: "szkolenie z obsługi,"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            className: "flex items-center py-4 mb-8",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    className: "mr-2",
                                    width: 20,
                                    height: 20,
                                    viewBox: "0 0 20 20",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        fillRule: "evenodd",
                                        clipRule: "evenodd",
                                        d: "M5.67 0H14.34C17.73 0 20 2.38 20 5.92V14.091C20 17.62 17.73 20 14.34 20H5.67C2.28 20 0 17.62 0 14.091V5.92C0 2.38 2.28 0 5.67 0ZM9.43 12.99L14.18 8.24C14.52 7.9 14.52 7.35 14.18 7C13.84 6.66 13.28 6.66 12.94 7L8.81 11.13L7.06 9.38C6.72 9.04 6.16 9.04 5.82 9.38C5.48 9.72 5.48 10.27 5.82 10.62L8.2 12.99C8.37 13.16 8.59 13.24 8.81 13.24C9.04 13.24 9.26 13.16 9.43 12.99Z",
                                        fill: "#45C1FF"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "font-medium",
                                    children: "nielimitowana ilość poprawek."
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(atoms_button, {
                    path: "#contactSection",
                    children: "Zapytaj o szczeg\xf3ły"
                })
            ]
        })
    });
};
/* harmony default export */ const pricing_card_premium = (PricingcardPremium);

;// CONCATENATED MODULE: ./components/molecules/pricing-card-standard/index.tsx



const PricingcardStandard = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "w-full md:w-1/2 lg:w-1/3 px-3",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "pt-12 pb-8 px-8 border border-red-400 rounded-xl lg:text-center",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                    className: "mb-6 font-semibold text-gray-500",
                    children: "Standard"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex lg:justify-center mb-8",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "self-start inline-block mr-2 font-semibold text-gray-500",
                            children: "od"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "self-end text-5xl font-semibold font-heading",
                            children: "1390 zł"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                    className: "mb-6 text-left",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            className: "flex items-center py-4 border-b",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    className: "mr-2",
                                    width: 20,
                                    height: 20,
                                    viewBox: "0 0 20 20",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        fillRule: "evenodd",
                                        clipRule: "evenodd",
                                        d: "M5.67 0H14.34C17.73 0 20 2.38 20 5.92V14.091C20 17.62 17.73 20 14.34 20H5.67C2.28 20 0 17.62 0 14.091V5.92C0 2.38 2.28 0 5.67 0ZM9.43 12.99L14.18 8.24C14.52 7.9 14.52 7.35 14.18 7C13.84 6.66 13.28 6.66 12.94 7L8.81 11.13L7.06 9.38C6.72 9.04 6.16 9.04 5.82 9.38C5.48 9.72 5.48 10.27 5.82 10.62L8.2 12.99C8.37 13.16 8.59 13.24 8.81 13.24C9.04 13.24 9.26 13.16 9.43 12.99Z",
                                        fill: "#45C1FF"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "font-medium",
                                    children: "strona gł\xf3wna + do 4 podstron,"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            className: "flex items-center py-4 border-b",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    className: "mr-2",
                                    width: 20,
                                    height: 20,
                                    viewBox: "0 0 20 20",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        fillRule: "evenodd",
                                        clipRule: "evenodd",
                                        d: "M5.67 0H14.34C17.73 0 20 2.38 20 5.92V14.091C20 17.62 17.73 20 14.34 20H5.67C2.28 20 0 17.62 0 14.091V5.92C0 2.38 2.28 0 5.67 0ZM9.43 12.99L14.18 8.24C14.52 7.9 14.52 7.35 14.18 7C13.84 6.66 13.28 6.66 12.94 7L8.81 11.13L7.06 9.38C6.72 9.04 6.16 9.04 5.82 9.38C5.48 9.72 5.48 10.27 5.82 10.62L8.2 12.99C8.37 13.16 8.59 13.24 8.81 13.24C9.04 13.24 9.26 13.16 9.43 12.99Z",
                                        fill: "#45C1FF"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "font-medium",
                                    children: "responsywność,"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            className: "flex items-center py-4 border-b",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    className: "mr-2",
                                    width: 20,
                                    height: 20,
                                    viewBox: "0 0 20 20",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        fillRule: "evenodd",
                                        clipRule: "evenodd",
                                        d: "M5.67 0H14.34C17.73 0 20 2.38 20 5.92V14.091C20 17.62 17.73 20 14.34 20H5.67C2.28 20 0 17.62 0 14.091V5.92C0 2.38 2.28 0 5.67 0ZM9.43 12.99L14.18 8.24C14.52 7.9 14.52 7.35 14.18 7C13.84 6.66 13.28 6.66 12.94 7L8.81 11.13L7.06 9.38C6.72 9.04 6.16 9.04 5.82 9.38C5.48 9.72 5.48 10.27 5.82 10.62L8.2 12.99C8.37 13.16 8.59 13.24 8.81 13.24C9.04 13.24 9.26 13.16 9.43 12.99Z",
                                        fill: "#45C1FF"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "font-medium",
                                    children: "CMS,"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            className: "flex items-center py-4 border-b",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    className: "mr-2",
                                    width: 20,
                                    height: 20,
                                    viewBox: "0 0 20 20",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        fillRule: "evenodd",
                                        clipRule: "evenodd",
                                        d: "M5.67 0H14.34C17.73 0 20 2.38 20 5.92V14.091C20 17.62 17.73 20 14.34 20H5.67C2.28 20 0 17.62 0 14.091V5.92C0 2.38 2.28 0 5.67 0ZM9.43 12.99L14.18 8.24C14.52 7.9 14.52 7.35 14.18 7C13.84 6.66 13.28 6.66 12.94 7L8.81 11.13L7.06 9.38C6.72 9.04 6.16 9.04 5.82 9.38C5.48 9.72 5.48 10.27 5.82 10.62L8.2 12.99C8.37 13.16 8.59 13.24 8.81 13.24C9.04 13.24 9.26 13.16 9.43 12.99Z",
                                        fill: "#45C1FF"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "font-medium",
                                    children: "szkolenie z obsługi,"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            className: "flex items-center py-4 mb-8",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    className: "mr-2",
                                    width: 20,
                                    height: 20,
                                    viewBox: "0 0 20 20",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        fillRule: "evenodd",
                                        clipRule: "evenodd",
                                        d: "M5.67 0H14.34C17.73 0 20 2.38 20 5.92V14.091C20 17.62 17.73 20 14.34 20H5.67C2.28 20 0 17.62 0 14.091V5.92C0 2.38 2.28 0 5.67 0ZM9.43 12.99L14.18 8.24C14.52 7.9 14.52 7.35 14.18 7C13.84 6.66 13.28 6.66 12.94 7L8.81 11.13L7.06 9.38C6.72 9.04 6.16 9.04 5.82 9.38C5.48 9.72 5.48 10.27 5.82 10.62L8.2 12.99C8.37 13.16 8.59 13.24 8.81 13.24C9.04 13.24 9.26 13.16 9.43 12.99Z",
                                        fill: "#45C1FF"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "font-medium",
                                    children: "nielimitowana ilość poprawek."
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(atoms_button, {
                    path: "#contactSection",
                    children: "Zapytaj o szczeg\xf3ły"
                })
            ]
        })
    });
};
/* harmony default export */ const pricing_card_standard = (PricingcardStandard);

;// CONCATENATED MODULE: ./components/molecules/pricing-card-start/index.tsx



const PricingcardStart = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "w-full md:w-1/2 lg:w-1/3 px-3",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "pt-12 pb-8 px-8 bg-white border rounded-xl lg:text-center",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                    className: "mb-6 font-semibold text-gray-500",
                    children: "Start"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex lg:justify-center mb-8",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "self-start inline-block mr-2 font-semibold text-gray-500",
                            children: "od"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "self-end text-5xl font-semibold font-heading",
                            children: "990 zł"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                    className: "mb-6 text-left",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            className: "flex items-center py-4 border-b",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    className: "mr-2",
                                    width: 20,
                                    height: 20,
                                    viewBox: "0 0 20 20",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        fillRule: "evenodd",
                                        clipRule: "evenodd",
                                        d: "M5.67 0H14.34C17.73 0 20 2.38 20 5.92V14.091C20 17.62 17.73 20 14.34 20H5.67C2.28 20 0 17.62 0 14.091V5.92C0 2.38 2.28 0 5.67 0ZM9.43 12.99L14.18 8.24C14.52 7.9 14.52 7.35 14.18 7C13.84 6.66 13.28 6.66 12.94 7L8.81 11.13L7.06 9.38C6.72 9.04 6.16 9.04 5.82 9.38C5.48 9.72 5.48 10.27 5.82 10.62L8.2 12.99C8.37 13.16 8.59 13.24 8.81 13.24C9.04 13.24 9.26 13.16 9.43 12.99Z",
                                        fill: "#45C1FF"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "font-medium",
                                    children: "strona gł\xf3wna (strona one page),"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            className: "flex items-center py-4 border-b",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    className: "mr-2",
                                    width: 20,
                                    height: 20,
                                    viewBox: "0 0 20 20",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        fillRule: "evenodd",
                                        clipRule: "evenodd",
                                        d: "M5.67 0H14.34C17.73 0 20 2.38 20 5.92V14.091C20 17.62 17.73 20 14.34 20H5.67C2.28 20 0 17.62 0 14.091V5.92C0 2.38 2.28 0 5.67 0ZM9.43 12.99L14.18 8.24C14.52 7.9 14.52 7.35 14.18 7C13.84 6.66 13.28 6.66 12.94 7L8.81 11.13L7.06 9.38C6.72 9.04 6.16 9.04 5.82 9.38C5.48 9.72 5.48 10.27 5.82 10.62L8.2 12.99C8.37 13.16 8.59 13.24 8.81 13.24C9.04 13.24 9.26 13.16 9.43 12.99Z",
                                        fill: "#45C1FF"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "font-medium",
                                    children: "responsywność,"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            className: "flex items-center py-4 border-b",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    className: "mr-2",
                                    width: 20,
                                    height: 20,
                                    viewBox: "0 0 20 20",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        fillRule: "evenodd",
                                        clipRule: "evenodd",
                                        d: "M5.67 0H14.34C17.73 0 20 2.38 20 5.92V14.091C20 17.62 17.73 20 14.34 20H5.67C2.28 20 0 17.62 0 14.091V5.92C0 2.38 2.28 0 5.67 0ZM9.43 12.99L14.18 8.24C14.52 7.9 14.52 7.35 14.18 7C13.84 6.66 13.28 6.66 12.94 7L8.81 11.13L7.06 9.38C6.72 9.04 6.16 9.04 5.82 9.38C5.48 9.72 5.48 10.27 5.82 10.62L8.2 12.99C8.37 13.16 8.59 13.24 8.81 13.24C9.04 13.24 9.26 13.16 9.43 12.99Z",
                                        fill: "#45C1FF"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "font-medium",
                                    children: "CMS,"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            className: "flex items-center py-4 border-b",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    className: "mr-2",
                                    width: 20,
                                    height: 20,
                                    viewBox: "0 0 20 20",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        fillRule: "evenodd",
                                        clipRule: "evenodd",
                                        d: "M5.67 0H14.34C17.73 0 20 2.38 20 5.92V14.091C20 17.62 17.73 20 14.34 20H5.67C2.28 20 0 17.62 0 14.091V5.92C0 2.38 2.28 0 5.67 0ZM9.43 12.99L14.18 8.24C14.52 7.9 14.52 7.35 14.18 7C13.84 6.66 13.28 6.66 12.94 7L8.81 11.13L7.06 9.38C6.72 9.04 6.16 9.04 5.82 9.38C5.48 9.72 5.48 10.27 5.82 10.62L8.2 12.99C8.37 13.16 8.59 13.24 8.81 13.24C9.04 13.24 9.26 13.16 9.43 12.99Z",
                                        fill: "#45C1FF"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "font-medium",
                                    children: "szkolenie z obsługi,"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            className: "flex items-center py-4 mb-8",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    className: "mr-2",
                                    width: 20,
                                    height: 20,
                                    viewBox: "0 0 20 20",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        fillRule: "evenodd",
                                        clipRule: "evenodd",
                                        d: "M5.67 0H14.34C17.73 0 20 2.38 20 5.92V14.091C20 17.62 17.73 20 14.34 20H5.67C2.28 20 0 17.62 0 14.091V5.92C0 2.38 2.28 0 5.67 0ZM9.43 12.99L14.18 8.24C14.52 7.9 14.52 7.35 14.18 7C13.84 6.66 13.28 6.66 12.94 7L8.81 11.13L7.06 9.38C6.72 9.04 6.16 9.04 5.82 9.38C5.48 9.72 5.48 10.27 5.82 10.62L8.2 12.99C8.37 13.16 8.59 13.24 8.81 13.24C9.04 13.24 9.26 13.16 9.43 12.99Z",
                                        fill: "#45C1FF"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "font-medium",
                                    children: "nielimitowana ilość poprawek."
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(atoms_button, {
                    path: "#contactSection",
                    children: "Zapytaj o szczeg\xf3ły"
                })
            ]
        })
    });
};
/* harmony default export */ const pricing_card_start = (PricingcardStart);

;// CONCATENATED MODULE: ./components/organisms/pricing-section/index.tsx






const PricingSection = ()=>{
    return(// <section className="py-20 bg-gray-50" id="pricingSection">
    //   <div className="container px-4 mx-auto">
    //     <div className="flex flex-wrap items-center -mx-3">
    //       <div className="w-full lg:w-1/3 px-3 mb-10 lg:mb-0">
    //         <SectionHeader
    //           superTitle="strony jak się patrzy"
    //           title="Ceny aktualne do 23 lipca"
    //         ></SectionHeader>
    //         <p className="text-xl text-gray-500">
    //           Wycena obejmuje podstawową funkcjonalność strony. W przypadku
    //           większej liczby podstron oraz dodatkowych funkcjonalności (np.
    //           różne wersje językowe, formularze, niestandardowe animacje) wycena
    //           indywidualna. Ceny netto.
    //         </p>
    //       </div>
    //       <PricingcardStandard />
    //       <PricingcardPremium />
    //     </div>
    //   </div>
    // </section>
    /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "relative pt-20 pb-36",
        id: "pricingSection",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container px-4 mx-auto",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "max-w-2xl mb-28 mx-auto text-center",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(section_header, {
                            superTitle: "strony jak się patrzy",
                            title: "Podstawowy cennik",
                            isCentered: true
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "max-w-lg mx-auto text-xl text-gray-500",
                            children: "Wycena obejmuje podstawową funkcjonalność strony. W przypadku większej liczby podstron oraz dodatkowych funkcjonalności (np. r\xf3żne wersje językowe, formularze, niestandardowe animacje) wycena indywidualna. Nie jestem VATowcem, więc cena netto = cena brutto."
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex flex-wrap -mx-3 -mb-10 lg:-mb-16",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(pricing_card_start, {}),
                        /*#__PURE__*/ jsx_runtime_.jsx(pricing_card_standard, {}),
                        /*#__PURE__*/ jsx_runtime_.jsx(pricing_card_premium, {})
                    ]
                })
            ]
        })
    }));
};
/* harmony default export */ const pricing_section = (PricingSection);

;// CONCATENATED MODULE: ./components/organisms/project-Featured/index.tsx




const ProjectFeatured = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "relative py-20",
        id: "projectFeatured",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                className: "hidden md:block absolute top-0 left-0 mt-24",
                src: "blue-dot-left-bars.svg",
                alt: "ikona",
                width: 236,
                height: 102
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "relative container px-4 mx-auto text-center",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "max-w-2xl mx-auto",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(section_header, {
                            superTitle: "strony jak się patrzy",
                            title: "Przykładowe realizacje",
                            isCentered: true
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "mb-12 text-xl text-gray-500",
                            children: "Czy w tak przystępnych cenach możesz się spodziewać zadowalających efekt\xf3w? Sprawdź moje przykładowe realizacje - stronę fundacji oraz aplikację filmową."
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                className: "mx-auto",
                                src: "/jaksiepatrzy-mockup.jpg",
                                alt: "mockup witryny stronyjaksiepatrzy.pl",
                                width: 1200,
                                height: 800
                            })
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const project_Featured = (ProjectFeatured);

;// CONCATENATED MODULE: ./components/organisms/project-section/index.tsx







const ProjectSection = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "relative py-20 overflow-x-hidden",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container px-4 mx-auto",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full lg:w-1/2",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex flex-col sm:max-w-md",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(section_header, {
                                    superTitle: "przykładowe realizacje",
                                    title: "Nowa strona Fundacji Futprints"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(section_paragraph, {
                                    children: "Strona fundacji, kt\xf3ra zajmuje się wsparciem os\xf3b zagrożonych wykluczeniem, w szczeg\xf3lności os\xf3b w kryzysie bezdomności."
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(list_item, {
                                                children: "strona wielojęzyczna,"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(list_item, {
                                                children: "responsywność,"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(list_item, {
                                                children: "panel CMS."
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "my-8",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(atoms_button, {
                                        path: "https://futprints-website.vercel.app/",
                                        isExternalLink: true,
                                        isTargetBlank: true,
                                        children: "Przejdź do strony"
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        className: "mt-24 w-full lg:hidden",
                        src: "/futprints-mockup.jpg",
                        alt: "mockup strony Fundacji Futprints",
                        width: 1200,
                        height: 800
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "hidden lg:block lg:absolute lg:top-0 lg:mt-32 transition ease-in-out delay-150 lg:-mr-40 lg:right-0 lg:w-1/2 hover:-translate-x-60",
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    className: "h-full w-full",
                    src: "/futprints-mockup.jpg",
                    alt: "mockup strony Fundacji Futprints",
                    width: 1200,
                    height: 800
                })
            })
        ]
    });
};
/* harmony default export */ const project_section = (ProjectSection);

;// CONCATENATED MODULE: ./components/organisms/project-section-second/index.tsx







const ProjectSectionSecond = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "relative py-20 overflow-x-hidden",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container px-4 mx-auto",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full lg:w-1/2",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex flex-col sm:max-w-md",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(section_header, {
                                    superTitle: "przykładowe realizacje",
                                    title: "Co to za film"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(section_paragraph, {
                                    children: "Quiz filmowy nawiązujący do popularnego teleturnieju muzycznego. Czy zgadniesz tytuł po jednej sekundzie?"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(list_item, {
                                                children: "wyświetlane losowe fragmenty film\xf3w,"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(list_item, {
                                                children: "automatycznie liczone statystyki,"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(list_item, {
                                                children: "responsywność."
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "my-8",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(atoms_button, {
                                        path: "https://dariuszstawik.github.io/movie-challenge/",
                                        isExternalLink: true,
                                        isTargetBlank: true,
                                        children: "Przejdź do aplikacji"
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        className: "mt-24 w-full lg:hidden",
                        src: "/co-to-za-film-mockup.png",
                        alt: 'mockup aplikacji "Co to za film"',
                        width: 1200,
                        height: 800
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "hidden lg:block lg:absolute lg:top-0 lg:mt-32 transition ease-in-out delay-150 lg:-mr-40 lg:right-0 lg:w-1/2 hover:-translate-x-60",
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    className: "h-full w-full",
                    src: "/co-to-za-film-mockup.png",
                    alt: 'mockup aplikacji "Co to za film"',
                    width: 1200,
                    height: 800
                })
            })
        ]
    });
};
/* harmony default export */ const project_section_second = (ProjectSectionSecond);

// EXTERNAL MODULE: ./node_modules/next/dist/client/components/noop-head.js
var noop_head = __webpack_require__(252);
var noop_head_default = /*#__PURE__*/__webpack_require__.n(noop_head);
// EXTERNAL MODULE: ./node_modules/next/script.js
var script = __webpack_require__(1661);
var script_default = /*#__PURE__*/__webpack_require__.n(script);
;// CONCATENATED MODULE: ./app/page.tsx













function Home() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "relative",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((noop_head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "Strony jak się patrzy"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "Strony www jak się patrzy w cenach, jakich mało."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "og:title",
                        content: "Strony jak się patrzy"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                src: `https://www.googletagmanager.com/gtag/js?id=${process.env.NEXT_PUBLIC_GOOGLE_ANALYTICS}`
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                id: "google-analytics",
                children: `
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());
 
          gtag('config', '${process.env.NEXT_PUBLIC_GOOGLE_ANALYTICS}');
        `
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(header, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(about_section, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(offer_section, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(features_section, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(project_Featured, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(project_section, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(project_section_second, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(pricing_section, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(contact_section, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(footer, {})
        ]
    });
}


/***/ }),

/***/ 3174:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3180);
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__);
  

  /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props) => {
    const imageData = {"type":"image/x-icon","sizes":"any"}
    const imageUrl = (0,next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__.fillMetadataSegment)(".", props.params, "favicon.ico")

    return [{
      ...imageData,
      url: imageUrl + "",
    }]
  });

/***/ }),

/***/ 2817:
/***/ (() => {



/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [381,442], () => (__webpack_exec__(73)));
module.exports = __webpack_exports__;

})();